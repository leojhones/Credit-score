# [Credit-score](https://github.com/rhatiro/Credit-score/blob/main/Projeto%2001%20-%20Classificacao%20de%20credito%20-%20Roberto%20Hatiro.ipynb)

Repositório referente aos [exercícios do Módulo 8](https://github.com/rhatiro/Curso_EBAC-Profissao_Cientista_de_Dados/tree/main/Mo%CC%81dulo%2008%20-%20Git%20:%20GitHub%20-%20Controle%20de%20versionamento) do curso [Profissão: Cientista de Dados](https://github.com/rhatiro/Curso_EBAC-Profissao_Cientista_de_Dados), realizado pela EBAC.
